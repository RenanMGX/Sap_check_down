from Entities.sap_check import SapCheck

if __name__ == "__main__":
    SapCheck.fechar_app_sap()